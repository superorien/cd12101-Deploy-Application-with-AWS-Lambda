import * as React from 'react'

export function NotFound() {
  return <h1>Not Found</h1>
}
